<?php

echo "<pre>" . shell_exec("E7_comand6.sh") . "</pre>";

?>
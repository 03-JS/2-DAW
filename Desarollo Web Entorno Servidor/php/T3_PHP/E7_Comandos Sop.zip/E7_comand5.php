<?php

echo "<pre>" . shell_exec("E7_comand5.bat") . "</pre>";

?>
<?php

for ($i=1; $i <= 10; $i++) { 
    echo "<a href='E3_verTabla.php?numero=$i'>Ver la tabla del $i</a>";
    echo "<br>";
}

?>